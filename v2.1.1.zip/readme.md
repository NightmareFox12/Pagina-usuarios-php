# Pagina de login Usuarios
Pagina de usuarios usando php, y MySQL proyecto de la universidad.

Para poder usarla se necesita cumplir estas reglas:

1. Descargar el archivo .zip que tiene todo el contenido.
2.  Usar un programa que cree un servidor como XAMPP que funciona para todos los SO, y tener _conocimientos basicos sobre su uso._
3.  Importar el archivo *users_php.sql* para tener las mismas tablas que se usaron en este proyecto.


<p align="center">
<img width="600" alt="Relaciones" src="https://github.com/NightmareFox12/Pagina-usuarios-php/assets/112921490/161d120d-5437-4541-a5ef-f703f7fe5273">
</p>

